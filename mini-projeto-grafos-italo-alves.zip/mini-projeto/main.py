import pandas as pd
import networkx as nx
import matplotlib.pyplot as plt
from networkx.algorithms import bipartite



def get_genres_by_movie_id(user_id,movie_id, movies_df):
  
  if movie_id not in movies_df['movieId'].tolist():
        # Se o filme avaliado pelo user nao estive no arquivo movies_teste.csv, retorne -1 que significa lista de generos vazia
        #print (f"O filme de movieId: {movie_id} avaliado pelo usuário de userId: {user_id} não foi encontrado no arquivo movies_teste.csv !")
        return 'null'
  
  # Encontra a linha do filme no DataFrame
  movie_row = movies_df.loc[movies_df['movieId'].apply(lambda x: x == movie_id)]

  # Extrai os gêneros da linha do filme
  genres = movie_row['genres'].values[0]

  # Separa os gêneros em uma lista
  genres_list = genres.split("|")
  #print (f"O filme de movieId: {movie_id} pertence aos generos: {genres_list}.")

  return genres_list

# Função que retorna TRUE caso algum valor de lista1 ocorrer na lista2
def compara_listas(lista1, lista2):
    for valor in lista1:
        if valor in lista2:
            return True
    return False


# Ler o arquivo ratings_teste.csv
ratings_df = pd.read_csv('dataset/ratings_teste.csv', encoding='utf-8')

# Ler o arquivo movies_teste.csv
movies_df = pd.read_csv('dataset/movies_teste.csv', encoding='utf-8')

# Criar o grafo direcionado
G_ratings = nx.DiGraph()

#Adicionar os vértices que correspondem aos users
G_ratings.add_nodes_from(ratings_df['userId'], bipartite=0)

#Adicionar os vértices que correspondem aos movies
G_ratings.add_nodes_from(ratings_df['movieId'], bipartite=1)

# Adicionar as arestas ponderadas correspondentes aos ratings(avaliações) dos usuários aos filmes
for _, row in ratings_df.iterrows():
    G_ratings.add_edge(row['userId'], row['movieId'], weitght=row['rating'])

# Obter os 3 gêneros de filmes que mais comuns no arquivo movies.csv
genres = movies_df['genres'].str.split('|', n=-1).explode().value_counts()[:3].index.tolist()

# Cria um grafo que representa a comunidade do 1o genero de filme mais vezes avaliada
G_community1 = nx.Graph()
G_community1.genre = genres[0]
G_community1.users_in_community = []

# Cria um grafo que representa a comunidade do 2o genero de filme mais vezes avaliada
G_community2 = nx.Graph()
G_community2.genre = genres[1]
G_community2.users_in_community = []

# Cria um grafo que representa a comunidade do 3o genero de filme mais vezes avaliada
G_community3 = nx.Graph()
G_community3.genre = genres[2]
G_community3.users_in_community = []


print (f"Os gêneros de filmes mais comuns são: {genres}")

# Imprimir os nós, arestas e a primeira aresta com peso
print('>>> G_ratings.nodes()')
print(G_ratings.nodes())
print('>>> G_ratings.edges()')
print(G_ratings.edges())
print('>>> G_ratings.edges')
for edge in G_ratings.edges(data=True):
    print(edge)
print ("\n")

users = ratings_df['userId'].unique()

# Iterar sobre os usuários que fizeram avaliações
for userId in users:

    # Verifica se o nó pertence à bipartição 0 (users)
    #if data['bipartite'] == 0:
    #print (f"Analisando os filmes avaliados pelo user:{userId}..")

    # Para cada filme avaliado pelo usuário, pegue seu movieId
    for movie_id in G_ratings.neighbors(userId):

        # Obter o gênero do filme
        movie_genres = get_genres_by_movie_id(userId, movie_id, movies_df)
        #print(f'Movie {movie_id} pertence aos generos:{movie_genres}.')

        # Se o gênero do filme for um dos três gêneros mais comuns
        if compara_listas(movie_genres, genres)==True:

            # Adicionar o usuário à comunidade correspondente ao 1o genero mais avaliado
            if genres[0] in movie_genres:
                #print (f"O filme de movieId: {movie_id} pertence ao gênero {genres[0]}.")
                G_community1.add_node(userId)
                G_community1.users_in_community.append(userId)

            # Adicionar o usuário à comunidade correspondente ao 2o genero mais avaliado
            if genres[1] in movie_genres:
                #print (f"O filme de movieId: {movie_id} pertence ao gênero {genres[1]}.")
                G_community2.add_node(userId)
                G_community2.users_in_community.append(userId)

            # Adicionar o usuário à comunidade correspondente ao 3o genero mais avaliado
            if genres[2] in movie_genres:
                #print (f"O filme de movieId: {movie_id} pertence ao gênero {genres[2]}.")
                G_community3.add_node(userId)
                G_community3.users_in_community.append(userId)


# Crie arestas entre cada par de usuários que avaliaram o mesmo filme de de cada comunidade

# Comunidade1
for id_user1 in G_community1.users_in_community:
    for id_user2 in G_community1.users_in_community:
        if id_user1 != id_user2:
            for movie_id in G_ratings.neighbors(id_user1):
                if movie_id in G_ratings.neighbors(id_user2):
                    G_community1.add_edge(id_user1, id_user2)

# Comunidade2
for id_user1 in G_community2.users_in_community:
    for id_user2 in G_community2.users_in_community:
        if id_user1 != id_user2:
            for movie_id in G_ratings.neighbors(id_user1):
                if movie_id in G_ratings.neighbors(id_user2):
                    G_community2.add_edge(id_user1, id_user2)

# Comunidade3
for id_user1 in G_community3.users_in_community:
    for id_user2 in G_community3.users_in_community:
        if id_user1 != id_user2:
            for movie_id in G_ratings.neighbors(id_user1):
                if movie_id in G_ratings.neighbors(id_user2):
                    G_community3.add_edge(id_user1, id_user2)

'''
print ('\n')
print(f'>>> G_community1.nodes() - Comunidade do gênero: {G_community1.genre}')
print(G_community1.nodes())
print(f'>>> G_community1.edges()')
print(G_community1.edges())
print ("\n")


print(f'>>> G_community2.nodes() - Comunidade do gênero: {G_community2.genre}')
print(G_community2.nodes())
print(f'>>> G_community2.edges()')
print(G_community2.edges())
print ("\n")


print(f'>>> G_community3.nodes() - Comunidade do gênero: {G_community3.genre}')
print(G_community3.nodes())
print(f'>>> G_community3.edges()')
print(G_community3.edges())
print ("\n")'''

# Calcular a centralidade de cada vértice de cada comunidade
# Obter o vértice da maior centralidade, isto é, com maior grau de
# entrada. Com isso, teremos o usuário que mais fez avaliações em 
# cada comunidade, logo, o mais influente.

# Comunidade 1
graus_de_centralidade = nx.degree_centrality(G_community1)
mais_influente_1 = max(graus_de_centralidade, key=graus_de_centralidade.get)
print(f"Id do usuário mais influente da comunidade 1: {mais_influente_1}")

# Comunidade 2
graus_de_centralidade = nx.degree_centrality(G_community2)
mais_influente_2 = max(graus_de_centralidade, key=graus_de_centralidade.get)
print(f"Id do usuário mais influente da comunidade 2: {mais_influente_2}")

# Comunidade 3
graus_de_centralidade = nx.degree_centrality(G_community3)
mais_influente_3 = max(graus_de_centralidade, key=graus_de_centralidade.get)
print(f"Id do usuário mais influente da comunidade 3: {mais_influente_3}")


# Função para plotar o grafo e adicionar o texto ao lado
def plot_grafo_com_texto(G, mais_influente, texto):
    # Plotar o grafo
    nx.draw(G, with_labels=True, font_weight='bold')

    # Adicionar texto ao lado do gráfico
    plt.text(1.1, 0.5, f"{texto} {mais_influente}", transform=plt.gca().transAxes)

    # Mostrar o gráfico
    plt.show()

# Plotar o primeiro grafo
plot_grafo_com_texto(G_community1, mais_influente_1, "Id do usuário mais influente =")

# Plotar o segundo grafo
plot_grafo_com_texto(G_community2, mais_influente_2, "Id do usuário mais influente =")

# Plotar o terceiro grafo
plot_grafo_com_texto(G_community3, mais_influente_3, "Id do usuário mais influente =")